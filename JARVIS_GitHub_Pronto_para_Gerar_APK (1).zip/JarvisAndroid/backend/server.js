import express from "express";
import OpenAI from "openai";
import rateLimit from "express-rate-limit";

const app = express();
app.disable("x-powered-by");
app.use(express.json({ limit: "12kb" }));

const limiter = rateLimit({
  windowMs: 60 * 1000,
  limit: 15,
  standardHeaders: "draft-7",
  legacyHeaders: false,
  message: { error: "Muitas mensagens em pouco tempo. Aguarde um minuto." }
});
app.use("/chat", limiter);

app.get("/health", (_req, res) => res.json({ ok: true }));

app.post("/chat", async (req, res) => {
  try {
    if (!process.env.OPENAI_API_KEY) {
      return res.status(503).json({ error: "O servidor ainda não recebeu a chave de API." });
    }
    const message = typeof req.body?.message === "string" ? req.body.message.trim() : "";
    if (!message) return res.status(400).json({ error: "Envie uma mensagem." });
    if (message.length > 4000) return res.status(413).json({ error: "Mensagem muito longa." });

    const client = new OpenAI({ apiKey: process.env.OPENAI_API_KEY });
    const response = await client.responses.create({
      model: process.env.OPENAI_MODEL || "gpt-5.5",
      instructions: "Você é J.A.R.V.I.S., um assistente virtual útil, objetivo e educado. Responda em português brasileiro, com clareza e sem fingir que controla o celular. Não afirme ter executado ações no aparelho. Se não souber, diga isso.",
      input: message,
      max_output_tokens: 700
    });

    return res.json({ reply: response.output_text || "Não consegui gerar uma resposta agora." });
  } catch (error) {
    console.error("Erro ao responder:", error?.status || error?.message || "erro desconhecido");
    return res.status(500).json({ error: "O servidor não conseguiu obter uma resposta da IA. Confira a configuração e tente novamente." });
  }
});

const port = Number(process.env.PORT || 3000);
app.listen(port, "0.0.0.0", () => console.log(`JARVIS backend ativo na porta ${port}`));
