# J.A.R.V.I.S. Android + integração com OpenAI

Projeto Android (Android 10+) com widget nativo e interface de assistente. Esta versão inclui o cliente Android e um backend Node.js para conectar à OpenAI Responses API.

## O que foi adicionado
- Campo para configurar o endereço HTTPS do backend dentro do app.
- Botão para testar a conexão (`/health`).
- Mensagens digitadas ou reconhecidas por voz são enviadas ao backend.
- A resposta da IA aparece na interface e é lida pelo sintetizador de voz Android.
- Backend Node.js que chama a OpenAI Responses API.
- Limite simples de requisições por IP.

## Segurança importante
A chave `OPENAI_API_KEY` deve ficar somente como variável de ambiente no servidor. Nunca cole a chave no HTML, APK, Total Launcher, nem envie a chave nesta conversa. Uma chave exposta pode permitir uso indevido e gerar cobranças. A configuração da conta API e de qualquer cobrança deve ser feita e supervisionada por um responsável adulto.

## Configurar o servidor
1. Publique a pasta `backend` em um serviço de hospedagem que execute Node.js e forneça HTTPS.
2. Configure no painel privado do serviço a variável `OPENAI_API_KEY` com uma chave de projeto válida. Não coloque a chave no código.
3. Opcionalmente, configure `OPENAI_MODEL` (padrão `gpt-5.5`).
4. Instale dependências com `npm install` e inicie com `npm start`.
5. Teste `https://SEU-ENDERECO/health`. Deve responder `{"ok":true}`.

## Conectar o aplicativo
1. Instale/compile o app Android.
2. Abra o J.A.R.V.I.S.
3. No quadro “CONEXÃO COM IA”, informe somente o endereço HTTPS do backend, por exemplo `https://meu-servidor.example`.
4. Toque em “SALVAR E TESTAR CONEXÃO”. O status deve mostrar “SERVIDOR CONECTADO”.
5. Digite uma pergunta ou toque no microfone. O J.A.R.V.I.S. enviará o texto para a IA.

## Adicionar o widget no Android
Depois de instalar o aplicativo, pressione um espaço vazio da tela inicial > Widgets > J.A.R.V.I.S. e arraste o widget.

## Limitações
- Este ZIP é código-fonte, não APK pronto.
- A conexão não fica ativa até o backend ser publicado e receber a chave de API no ambiente seguro.
- O botão do widget abre o app; o widget não mantém microfone ativo em segundo plano.
- O backend de exemplo não inclui login de usuário; antes de disponibilizar publicamente, adicione autenticação e controles de uso adequados.

## Gerar o APK pelo GitHub Actions
O repositório inclui `.github/workflows/android-apk.yml`. Depois de enviar o projeto para GitHub:
1. Abra a aba **Actions** do repositório.
2. Aguarde o fluxo **Build JARVIS APK** terminar com sucesso.
3. Abra a execução concluída e baixe o artefato **JARVIS-Android-debug-APK**.
4. Extraia o ZIP do artefato; dentro estará `app-debug.apk`.

O APK gerado por esse fluxo é uma build de depuração, não uma versão assinada para publicação na Play Store.
