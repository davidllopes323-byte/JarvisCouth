package com.example.jarvis

import android.app.PendingIntent
import android.appwidget.AppWidgetManager
import android.appwidget.AppWidgetProvider
import android.content.Context
import android.content.Intent
import android.widget.RemoteViews
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale

class JarvisWidgetProvider : AppWidgetProvider() {
    override fun onUpdate(context: Context, manager: AppWidgetManager, ids: IntArray) {
        val time = SimpleDateFormat("HH:mm", Locale("pt", "BR")).format(Date())
        val date = SimpleDateFormat("EEEE, dd 'de' MMMM", Locale("pt", "BR")).format(Date())
            .replaceFirstChar { if (it.isLowerCase()) it.titlecase(Locale("pt", "BR")) else it.toString() }

        ids.forEach { id ->
            val views = RemoteViews(context.packageName, R.layout.jarvis_widget)
            views.setTextViewText(R.id.widget_time, time)
            views.setTextViewText(R.id.widget_date, date)
            views.setTextViewText(R.id.widget_status, "SISTEMA PRONTO")

            val openIntent = Intent(context, MainActivity::class.java)
            val pending = PendingIntent.getActivity(
                context, id, openIntent,
                PendingIntent.FLAG_UPDATE_CURRENT or PendingIntent.FLAG_IMMUTABLE
            )
            views.setOnClickPendingIntent(R.id.widget_activate, pending)
            views.setOnClickPendingIntent(R.id.widget_status, pending)
            views.setOnClickPendingIntent(R.id.widget_time, pending)
            views.setOnClickPendingIntent(R.id.widget_date, pending)
            views.setOnClickPendingIntent(R.id.widget_activate, pending)
            manager.updateAppWidget(id, views)
        }
    }
}
