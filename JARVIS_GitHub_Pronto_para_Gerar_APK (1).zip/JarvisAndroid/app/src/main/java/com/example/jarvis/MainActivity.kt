package com.example.jarvis

import android.Manifest
import android.app.Activity
import android.content.Intent
import android.content.pm.PackageManager
import android.os.Bundle
import android.speech.RecognizerIntent
import android.speech.TextToSpeech
import android.webkit.JavascriptInterface
import android.webkit.WebChromeClient
import android.webkit.WebView
import android.webkit.WebViewClient
import androidx.core.app.ActivityCompat
import androidx.core.content.ContextCompat
import org.json.JSONObject
import java.net.HttpURLConnection
import java.net.URL
import java.util.Locale
import java.util.concurrent.Executors

class MainActivity : Activity(), TextToSpeech.OnInitListener {
    private lateinit var webView: WebView
    private var tts: TextToSpeech? = null
    private val executor = Executors.newSingleThreadExecutor()
    private val audioRequestCode = 401
    private val speechRequestCode = 402

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        tts = TextToSpeech(this, this)
        webView = WebView(this)
        webView.settings.javaScriptEnabled = true
        webView.settings.domStorageEnabled = true
        webView.webChromeClient = WebChromeClient()
        webView.webViewClient = WebViewClient()
        webView.addJavascriptInterface(JarvisBridge(), "AndroidJarvis")
        setContentView(webView)
        webView.loadUrl("file:///android_asset/index.html")
    }

    override fun onInit(status: Int) {
        if (status == TextToSpeech.SUCCESS) tts?.language = Locale("pt", "BR")
    }

    inner class JarvisBridge {
        @JavascriptInterface
        fun speak(message: String) {
            runOnUiThread {
                tts?.speak(message.take(1500), TextToSpeech.QUEUE_FLUSH, null, "jarvis-utterance")
            }
        }

        @JavascriptInterface
        fun startListening() {
            runOnUiThread {
                if (ContextCompat.checkSelfPermission(this@MainActivity, Manifest.permission.RECORD_AUDIO)
                    != PackageManager.PERMISSION_GRANTED) {
                    ActivityCompat.requestPermissions(
                        this@MainActivity, arrayOf(Manifest.permission.RECORD_AUDIO), audioRequestCode
                    )
                    return@runOnUiThread
                }
                val intent = Intent(RecognizerIntent.ACTION_RECOGNIZE_SPEECH).apply {
                    putExtra(RecognizerIntent.EXTRA_LANGUAGE_MODEL, RecognizerIntent.LANGUAGE_MODEL_FREE_FORM)
                    putExtra(RecognizerIntent.EXTRA_LANGUAGE, "pt-BR")
                    putExtra(RecognizerIntent.EXTRA_PROMPT, "Fale com o JARVIS")
                }
                try {
                    startActivityForResult(intent, speechRequestCode)
                } catch (_: Exception) {
                    sendToPage("window.onJarvisError('Não foi possível iniciar o reconhecimento de voz.')")
                }
            }
        }

        @JavascriptInterface
        fun askAI(message: String, endpoint: String) {
            executor.execute {
                try {
                    val base = endpoint.trim().trimEnd('/')
                    require(base.startsWith("https://")) { "O endereço do servidor precisa começar com https://" }
                    val url = URL("$base/chat")
                    val conn = (url.openConnection() as HttpURLConnection).apply {
                        requestMethod = "POST"
                        connectTimeout = 15000
                        readTimeout = 60000
                        doOutput = true
                        setRequestProperty("Content-Type", "application/json; charset=utf-8")
                    }
                    val body = JSONObject().put("message", message.take(4000)).toString()
                    conn.outputStream.use { it.write(body.toByteArray(Charsets.UTF_8)) }
                    val code = conn.responseCode
                    val stream = if (code in 200..299) conn.inputStream else conn.errorStream
                    val raw = stream.bufferedReader().use { it.readText() }
                    conn.disconnect()
                    val json = JSONObject(raw)
                    if (code !in 200..299) {
                        throw IllegalStateException(json.optString("error", "Erro do servidor (HTTP $code)."))
                    }
                    val answer = json.optString("reply", "").ifBlank { "Não recebi uma resposta válida." }
                    sendToPage("window.onJarvisAIResponse(${JSONObject.quote(answer)})")
                } catch (e: Exception) {
                    val msg = e.message ?: "Falha ao conectar com a IA."
                    sendToPage("window.onJarvisError(${JSONObject.quote(msg)})")
                }
            }
        }

        @JavascriptInterface
        fun checkAI(endpoint: String) {
            executor.execute {
                try {
                    val base = endpoint.trim().trimEnd('/')
                    require(base.startsWith("https://")) { "Use o endereço HTTPS do seu servidor." }
                    val conn = (URL("$base/health").openConnection() as HttpURLConnection).apply {
                        connectTimeout = 10000
                        readTimeout = 10000
                    }
                    val code = conn.responseCode
                    conn.disconnect()
                    if (code in 200..299) sendToPage("window.onJarvisConnection(true)")
                    else throw IllegalStateException("Servidor respondeu HTTP $code.")
                } catch (e: Exception) {
                    sendToPage("window.onJarvisConnection(false, ${JSONObject.quote(e.message ?: "Não conectado")})")
                }
            }
        }

        @JavascriptInterface
        fun openApp(packageName: String) {
            val allowed = setOf(
                "com.android.chrome", "com.whatsapp",
                "com.google.android.youtube", "com.android.settings"
            )
            if (packageName !in allowed) return
            runOnUiThread {
                val launch = packageManager.getLaunchIntentForPackage(packageName)
                if (launch != null) startActivity(launch)
                else sendToPage("window.onJarvisError('Esse aplicativo não foi encontrado.')")
            }
        }
    }

    @Deprecated("Legacy activity result API kept for broad Android compatibility")
    override fun onActivityResult(requestCode: Int, resultCode: Int, data: Intent?) {
        super.onActivityResult(requestCode, resultCode, data)
        if (requestCode == speechRequestCode && resultCode == RESULT_OK) {
            val spoken = data?.getStringArrayListExtra(RecognizerIntent.EXTRA_RESULTS)?.firstOrNull()
            if (spoken != null) sendToPage("window.onJarvisSpeech(${JSONObject.quote(spoken)})")
        }
    }

    private fun sendToPage(script: String) {
        if (::webView.isInitialized) webView.post { webView.evaluateJavascript(script, null) }
    }

    override fun onDestroy() {
        tts?.stop()
        tts?.shutdown()
        executor.shutdownNow()
        if (::webView.isInitialized) webView.destroy()
        super.onDestroy()
    }
}
